export interface Garment {
  id: number;
  name: string;
  src: string;
  category: string;
}
